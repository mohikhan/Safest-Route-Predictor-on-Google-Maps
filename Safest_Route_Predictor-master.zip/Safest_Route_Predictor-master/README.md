# Safest_Route_Predictor
A GUI application built using Tkinter which predicts the safest route between two locations.

# Demo Images

## GUI Application

![GUI App](/images/gui_app.png)
